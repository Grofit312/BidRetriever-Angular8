'use strict';

const MailParser = require('./lib/mail-parser');
const simpleParser = require('./lib/simple-parser');

module.exports = {
    MailParser,
    simpleParser
};
